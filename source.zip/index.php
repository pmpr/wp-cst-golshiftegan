<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a7a9ada             |
    |_______________________________________|
*/
 use Pmpr\Custom\Golshiftegan\Golshiftegan; Golshiftegan::symcgieuakksimmu(); if (!function_exists('pr_get_dokan_template_params')) { function pr_get_dokan_template_params($uusmaiomayssaecw = null, $ggauoeuaesiymgee = null) { $eyagkkkqkwcuygso = $GLOBALS['pr_dokan_template_params'] ?? []; if ($uusmaiomayssaecw === null) { return $eyagkkkqkwcuygso; } return $eyagkkkqkwcuygso[$uusmaiomayssaecw] ?? $ggauoeuaesiymgee; } }
