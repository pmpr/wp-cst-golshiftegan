<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693401c982bc9             |
    |_______________________________________|
*/
 use Pmpr\Custom\Golshiftegan\Golshiftegan; Golshiftegan::symcgieuakksimmu();
