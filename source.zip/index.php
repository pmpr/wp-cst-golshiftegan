<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6930229c80869             |
    |_______________________________________|
*/
 use Pmpr\Custom\Golshiftegan\Golshiftegan; Golshiftegan::symcgieuakksimmu();
