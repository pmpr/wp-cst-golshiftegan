<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693025242694a             |
    |_______________________________________|
*/
 use Pmpr\Custom\Golshiftegan\Golshiftegan; Golshiftegan::symcgieuakksimmu();
