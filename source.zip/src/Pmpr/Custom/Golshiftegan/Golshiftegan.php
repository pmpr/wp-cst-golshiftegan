<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6930229c80869             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; class Golshiftegan extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __('Travel Fantasy Custom', PR__CST__GOLSHIFTEGAN); }, Constants::wuowaiyouwecckaw => false]); } public function aqyikqugcomoqqqi() { $qgiimcueymgqcsai = $this->caokeucsksukesyo()->cqusmgskowmesgcg(); if ($qgiimcueymgqcsai->iqqgmieeqemiowuk('jalali')) { Jalali::symcgieuakksimmu(); } } }
