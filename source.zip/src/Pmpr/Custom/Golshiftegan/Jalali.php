<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b5a611c047             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan; class Jalali extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('jalali_datepicker_custom_colors', [$this, 'acumoyeimyciuuuo']); } public function acumoyeimyciuuuo($ukqisiguweqciuei) { $ukqisiguweqciuei['header-row-bg'] = '#008612'; $ukqisiguweqciuei['header-row-color'] = '#FFF'; $ukqisiguweqciuei['date-item-hover-bg'] = '#094E10'; $ukqisiguweqciuei['date-item-selected-bg'] = '#008612'; $ukqisiguweqciuei['persian-to-gregorian-btn'] = '"Dana", Arial, sans-serif'; return $ukqisiguweqciuei; } }
