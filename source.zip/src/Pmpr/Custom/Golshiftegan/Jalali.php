<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693025242694a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan; class Jalali extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('jalali_datepicker_custom_colors', [$this, 'acumoyeimyciuuuo']); } public function acumoyeimyciuuuo($ukqisiguweqciuei) { $ukqisiguweqciuei['date-item-hover-bg'] = '#008612'; $ukqisiguweqciuei['date-item-selected-bg'] = '#094E10'; $ukqisiguweqciuei['header-row-bg'] = '#094E10'; $ukqisiguweqciuei['header-row-color'] = '#FFF'; return $ukqisiguweqciuei; } }
