<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a7a9ada             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
