<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b611fac7be             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
