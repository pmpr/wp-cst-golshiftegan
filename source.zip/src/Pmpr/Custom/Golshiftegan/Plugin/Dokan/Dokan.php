<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a7a9ada             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Dokan; use Pmpr\Custom\Golshiftegan\Container; class Dokan extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('wp', [$this, 'gosmqcmmomkqwmis']); } public function mameiwsayuyquoeq() { Order::symcgieuakksimmu(); Vendor::symcgieuakksimmu(); Withdraw::symcgieuakksimmu(); } public function gosmqcmmomkqwmis() { if ($this->uwkmaywceaaaigwo()->gmymsiemouuyyocw()->usgmmimoysimeueu()) { SellerDashboard::symcgieuakksimmu(); } } }
