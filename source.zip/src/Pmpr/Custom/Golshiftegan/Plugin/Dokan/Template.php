<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d407b242             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Dokan; use Pmpr\Custom\Golshiftegan\Container; abstract class Template extends Container { protected array $args = []; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('dokan_set_template_path', [$this, 'suockgmsmwscagio'], 10, 3)->cecaguuoecmccuse('dokan_get_template_part', [$this, 'msmomkmyioykwmwi'], 10, 2); } public function imkyoqyocosuqasu($ymqmyyeuycgmigyo, $ggauoeuaesiymgee = null) { return $this->args[$ymqmyyeuycgmigyo] ?? $ggauoeuaesiymgee; } public function iioeimqcocgciyuu($eyagkkkqkwcuygso) { $GLOBALS['pr_dokan_template_params'] = $eyagkkkqkwcuygso; } public function suockgmsmwscagio($esaqeawoigqgagum, $qqscaoyqikuyeoaw, $ywmkwiwkosakssii = []) { if (is_array($ywmkwiwkosakssii)) { $this->args = $ywmkwiwkosakssii; } else { $this->args = []; } return $esaqeawoigqgagum; } public function msmomkmyioykwmwi($qqscaoyqikuyeoaw, $aaokuekaimigoyue) { $yckmgmauyymwimug = $this->smuiimegiweoaeia($aaokuekaimigoyue, $qqscaoyqikuyeoaw); if ($yckmgmauyymwimug) { $qqscaoyqikuyeoaw = $yckmgmauyymwimug; } return $qqscaoyqikuyeoaw; } public abstract function smuiimegiweoaeia($aaokuekaimigoyue, $qqscaoyqikuyeoaw) : ?string; }
