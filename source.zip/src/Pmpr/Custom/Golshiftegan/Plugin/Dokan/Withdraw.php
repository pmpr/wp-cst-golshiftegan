<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b611fac7be             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Dokan; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Golshiftegan\Container; use Pmpr\Custom\Golshiftegan\Traits\OrderTrait; class Withdraw extends Container { use OrderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('dokan_withdraw_active_status', [$this, 'gmussyqiuqikwgyc'])->cecaguuoecmccuse('dokan_settings_withdraw_order_status_options', [$this, 'gwwuoymwoyqcyyss']); } public function gmussyqiuqikwgyc($sikqkucuwsoieowc) { $sikqkucuwsoieowc = $this->awyaawmockcwmkcy($sikqkucuwsoieowc); return $sikqkucuwsoieowc; } public function gwwuoymwoyqcyyss($qiouiwasaauyaaue) { return $this->yuuaegusqiakwumi($qiouiwasaauyaaue); } }
