<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a7a9ada             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Dokan; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Golshiftegan\Container; use Pmpr\Custom\Golshiftegan\Traits\OrderTrait; class Vendor extends Container { use OrderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('dokan_get_vendor_orders_args', [$this, 'mcqycyiysgueqiis']); } public function mcqycyiysgueqiis($ywmkwiwkosakssii) { if (isset($ywmkwiwkosakssii[Constants::ciywsqoeiymemsys])) { $ywmkwiwkosakssii[Constants::ciywsqoeiymemsys] = $this->awyaawmockcwmkcy($ywmkwiwkosakssii[Constants::ciywsqoeiymemsys]); } return $ywmkwiwkosakssii; } }
