<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b5a611c047             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Woocommerce\Email; class CustomerApprovedOrder extends Email { }
