<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d407b242             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Woocommerce\Email; class CustomerApprovedOrder extends Email { }
