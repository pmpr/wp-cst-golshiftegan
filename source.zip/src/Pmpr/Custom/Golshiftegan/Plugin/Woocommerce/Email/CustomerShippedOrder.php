<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b611fac7be             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Woocommerce\Email; class CustomerShippedOrder extends Email { }
