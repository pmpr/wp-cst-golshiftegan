<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693893a7a9ada             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Golshiftegan\Plugin\Woocommerce; use Pmpr\Custom\Golshiftegan\Container; class Woocommerce extends Container { public function mameiwsayuyquoeq() { Order::symcgieuakksimmu(); } }
